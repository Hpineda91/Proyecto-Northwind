﻿using Domain.Models.DTO;
using Domain.Models.Interfaces;
using Microsoft.EntityFrameworkCore.Infrastructure;
using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Linq;
using System.Reflection;
using System.Reflection.Metadata;
using System.Text;
using System.Threading.Tasks;

namespace Domain.Services
{
    public class CustomerServices
    {
        private readonly ICustomer _customer;

        public CustomerServices(ICustomer customer)
        {
            _customer = customer;
        }
        public async Task<List<CustomerDto>> GetCustomers()
        {
            return await _customer.GetCustomers();
        }
    }
}
