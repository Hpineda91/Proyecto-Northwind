﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using DataAccess.Models;
using Domain.Models.DTO;

namespace DataAccess.Mappers
{
    public class CustomerMap
    {
        public static CustomerDto ToDto(Customer customer)
        {
            return new CustomerDto
            {
                Id = customer.CustomerID,
                CompanyName = customer.CompanyName,
                ContactName = customer.ContactName,
                Country = customer.Country
            };
        }
        public static Customer ToEntity(CustomerDto customerdto)
        {
            return new Customer
            {
                CustomerID = customerdto.CustomerID,
                Address = customerdto.Address,
                City = customerdto.City,
                CompanyName = customerdto.CompanyName,
                ContactName = customerdto.ContactName,
                ContactTitle = customerdto.ContactTitle,
                Country = customerdto.Country,
                Fax = customerdto.Fax,
                Phone = customerdto.Phone,
                PostalCode = customerdto.PostalCode,
                Region = customerdto.Region,
            };
        }
    }
}